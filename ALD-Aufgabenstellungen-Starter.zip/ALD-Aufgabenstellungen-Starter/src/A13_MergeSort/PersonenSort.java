package A13_MergeSort;


public interface PersonenSort {

	public void sort(Person[] personen);

}
