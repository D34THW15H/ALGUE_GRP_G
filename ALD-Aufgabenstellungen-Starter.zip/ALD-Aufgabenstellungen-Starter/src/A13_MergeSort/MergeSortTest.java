package A13_MergeSort;

import org.junit.Before;

public class MergeSortTest extends PersonenSortTest {

	@Before
	public void setUp() {
		ps = new MergeSort();
	}

}
