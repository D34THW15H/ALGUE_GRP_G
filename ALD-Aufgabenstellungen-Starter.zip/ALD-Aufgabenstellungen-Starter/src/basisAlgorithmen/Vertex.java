package basisAlgorithmen;

public class Vertex {
	public int vertex;
	public int cost;

	public Vertex(int vertex, int cost) {
		this.vertex = vertex;
		this.cost = cost;
	}
	
}
