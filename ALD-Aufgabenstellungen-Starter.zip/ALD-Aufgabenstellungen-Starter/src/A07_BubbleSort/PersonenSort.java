package A07_BubbleSort;


public interface PersonenSort {

	public void sort(Person[] personen);

}
