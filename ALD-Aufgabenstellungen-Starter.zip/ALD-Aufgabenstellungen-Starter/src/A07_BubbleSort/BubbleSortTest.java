package A07_BubbleSort;

import org.junit.Before;

public class BubbleSortTest extends PersonenSortTest {

	@Before
	public void setUp() {
		ps = new BubbleSort();
	}

}
