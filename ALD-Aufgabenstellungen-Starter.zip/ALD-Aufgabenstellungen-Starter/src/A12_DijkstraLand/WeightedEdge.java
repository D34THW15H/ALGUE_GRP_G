package A12_DijkstraLand;

public class WeightedEdge {
	public int vertex;
	public int weight;

	public WeightedEdge(int v, int weight) {
		this.vertex = v;
		this.weight = weight;
	}
}
