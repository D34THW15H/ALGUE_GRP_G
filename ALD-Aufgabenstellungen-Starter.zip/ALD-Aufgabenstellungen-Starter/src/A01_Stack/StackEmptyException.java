package A01_Stack;

public class StackEmptyException extends Exception {

	private static final long serialVersionUID = 52034036L;

}
