package A03_DoubleLinkedList;

public class CurrentNotSetException extends Exception {

	private static final long serialVersionUID = 251858618L;

}
